
const admin = require('firebase-admin');
const fs1 = require('fs');
const path1 = require('path');

admin.initializeApp();

module.exports = admin;

