export class MockAuthService {

  ensureLogin = (url?: string) => {};
  logout = () => {}

}
