export class SocialGameScoreShare {
    filename: number;
    created_uid: string;
}
