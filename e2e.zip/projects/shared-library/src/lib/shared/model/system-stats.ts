

export class SystemStats {
    total_users?: number;
    total_questions?: number;
    active_games?: number;
    game_played?: number;
}
