export class Subscription {
    id?: string;
    userId?: string;
    email: string;
}
