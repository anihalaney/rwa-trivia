export class Category {
  id: number;
  categoryName: string;
  requiredForGamePlay?: boolean;
}
