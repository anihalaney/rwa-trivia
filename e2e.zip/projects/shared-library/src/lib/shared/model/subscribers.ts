

export class Subscribers {
    count?: number;
}
