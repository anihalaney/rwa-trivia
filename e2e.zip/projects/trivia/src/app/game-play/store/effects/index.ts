import { GamePlayEffects } from './game-play.effects';

export * from './game-play.effects';

export const effects = [
  GamePlayEffects
];

