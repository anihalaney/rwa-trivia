import { StatsEffects } from './stats.effects';
export * from './stats.effects';

export const effects = [
  StatsEffects
];
