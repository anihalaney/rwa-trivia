import { UserEffects } from './user.effects';

export * from './user.effects';

export const effects = [
  UserEffects
];

