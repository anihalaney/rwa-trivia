import { SocialEffects } from './social.effects';

export * from './social.effects';

export const effects = [
  SocialEffects
];

